from PySide6.QtWidgets import (
    QMainWindow, QDialog, QFileDialog, QMessageBox, QApplication, QInputDialog,
    QVBoxLayout, QListWidget, QListWidgetItem, QDialogButtonBox, QPushButton
)
from PySide6.QtGui import QPixmap
from PySide6.QtCore import QThread, Signal, Qt, QPoint, QTimer
import sys
import socket
import random

# ===== Clases de Chats =====
class PrivChat():
    def __init__(self, idx, nme):
        self.chname = nme
        self.idx = idx

class GroupChat():
    def __init__(self, name, members):
        self.name = name
        self.members = members

# ===== Hilo de conexión al servidor =====
class ThreadSocket(QThread):
    signal_message = Signal(str)

    def __init__(self, host, port, name, parent=None):
        super().__init__(parent)
        self.host = host
        self.port = port
        self.name = name
        self.connected = False
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def run(self):
        try:
            self.server.connect((self.host, self.port))
            self.connected = True
            self.server.send(bytes(f"<name>{self.name}", 'utf-8'))

            while self.connected:
                message = self.server.recv(1024)
                if message:
                    self.signal_message.emit(message.decode("utf-8"))
                else:
                    self.signal_message.emit("<!!disconnected!!>")
                    break

        except Exception as e:
            self.signal_message.emit(f"<!!error!!> {str(e)}")
        finally:
            self.server.close()
            self.connected = False

    def stop(self):
        self.connected = False
        self.wait()

# ===== Ventana principal =====
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Messenger con Grupos y Zumbidos")
        self.resize(800, 600)

        # Interfaz mínima manual sin Ui para simplificar aquí
        from PySide6.QtWidgets import QTextEdit, QLineEdit, QLabel

        self.plainTextEdit = QTextEdit(self)
        self.plainTextEdit.setGeometry(20, 50, 760, 400)

        self.lineEdit = QLineEdit(self)
        self.lineEdit.setGeometry(20, 470, 600, 30)

        self.Boton_Enviar = QPushButton("Enviar", self)
        self.Boton_Enviar.setGeometry(640, 470, 140, 30)

        self.Boton_NuevoChat = QPushButton("Nuevo Chat/Grupo", self)
        self.Boton_NuevoChat.setGeometry(20, 10, 200, 30)

        self.Boton_ChatG = QPushButton("Chat General", self)
        self.Boton_ChatG.setGeometry(230, 10, 150, 30)

        self.Boton_Zumbido = QPushButton("Enviar Zumbido", self)
        self.Boton_Zumbido.setGeometry(390, 10, 150, 30)

        self.label_5 = QLabel("", self)
        self.label_5.setGeometry(600, 10, 180, 30)

        self.connection = None
        self.current_user = None
        self.private_chats = []
        self.group_chats = []
        self.current_chat = None

        self.Boton_Enviar.clicked.connect(self.send_message)
        self.lineEdit.returnPressed.connect(self.send_message)
        self.Boton_ChatG.clicked.connect(lambda: self.show_chat("General"))
        self.Boton_NuevoChat.clicked.connect(self.new_chat)
        self.Boton_Zumbido.clicked.connect(self.send_nudge)

        self.show_login_window()

    def show_login_window(self):
        username, ok = QInputDialog.getText(self, "Login", "Escribe tu nombre de usuario:")
        if ok and username:
            self.current_user = username
            self.connect_to_server("127.0.0.1", 65535)

    def connect_to_server(self, host, port):
        try:
            self.connection = ThreadSocket(host, int(port), self.current_user)
            self.connection.signal_message.connect(self.receive_message)
            self.connection.start()
            self.setWindowTitle(f"Conectado como {self.current_user}")
            self.label_5.setText(f"Hola: {self.current_user}")
            self.plainTextEdit.appendPlainText(f"Conectado al servidor {host}:{port}\n")
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo conectar: {str(e)}")
            return False

    def send_message(self):
        if not (self.connection and self.connection.connected):
            QMessageBox.warning(self, "Error", "No estás conectado al servidor")
            return

        message = self.lineEdit.text().strip()
        if not message:
            return

        try:
            if self.current_chat:
                if isinstance(self.current_chat, PrivChat):
                    full_msg = f"<private>{self.current_chat.chname}:{message}"
                elif isinstance(self.current_chat, GroupChat):
                    full_msg = f"<group>{self.current_chat.name}:{message}"
                self.connection.server.send(bytes(full_msg, 'utf-8'))
                self.plainTextEdit.appendPlainText(f"<Tú a {self.current_chat.name}> {message}\n")
            else:
                self.connection.server.send(bytes(message, 'utf-8'))
                self.plainTextEdit.appendPlainText(f"<Tú> {message}\n")

            self.lineEdit.clear()
        except Exception as e:
            self.plainTextEdit.appendPlainText(f"<!!error al enviar!!> {str(e)}\n")

    def receive_message(self, message):
        if message.startswith("<nudge>"):
            sender = message.removeprefix("<nudge>").strip()
            self.plainTextEdit.appendPlainText(f"** Has recibido un zumbido de {sender}! **\n")
            self.shake_window()
            return

        if message.startswith("Usuarios conectados:"):
            users = message.split("\n")[1:]
            users = [u.strip() for u in users if u.strip() and u.strip() != self.current_user]

            if not users:
                QMessageBox.information(self, "Nuevo Chat", "No hay otros usuarios conectados")
                return

            dialog = MultiSelectDialog(users)
            if dialog.exec() == QDialog.Accepted:
                selected = dialog.get_selected_users()
                if len(selected) == 1:
                    self.start_private_chat(selected[0])
                else:
                    group_name, ok = QInputDialog.getText(self, "Nombre del Grupo", "Ingrese el nombre del grupo:")
                    if ok and group_name:
                        self.start_group_chat(group_name, selected)
        else:
            self.plainTextEdit.appendPlainText(message)

    def start_private_chat(self, username):
        for chat in self.private_chats:
            if chat.chname == username:
                self.current_chat = chat
                self.plainTextEdit.clear()
                self.plainTextEdit.appendPlainText(f"Chat privado con {username}:\n")
                return

        new_chat = PrivChat(len(self.private_chats), username)
        self.private_chats.append(new_chat)
        self.current_chat = new_chat
        self.plainTextEdit.clear()
        self.plainTextEdit.appendPlainText(f"Iniciando chat privado con {username}...\n")
        try:
            self.connection.server.send(bytes(f"<private>{username}", 'utf-8'))
        except Exception as e:
            self.plainTextEdit.appendPlainText(f"Error al iniciar chat privado: {str(e)}\n")

    def start_group_chat(self, group_name, members):
        new_group = GroupChat(group_name, members)
        self.group_chats.append(new_group)
        self.current_chat = new_group
        self.plainTextEdit.clear()
        self.plainTextEdit.appendPlainText(f"Iniciando grupo '{group_name}' con: {', '.join(members)}\n")
        try:
            self.connection.server.send(bytes(f"<creategroup>{group_name}:{','.join(members)}", 'utf-8'))
        except Exception as e:
            self.plainTextEdit.appendPlainText(f"Error al crear grupo: {str(e)}\n")

    def new_chat(self):
        if not self.connection or not self.connection.connected:
            QMessageBox.warning(self, "Error", "No estás conectado al servidor")
            return
        try:
            self.connection.server.send(bytes("<command>list", 'utf-8'))
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo obtener la lista de usuarios: {str(e)}")

    def show_chat(self, chat_type):
        if chat_type == "General":
            self.current_chat = None
            self.plainTextEdit.clear()
            self.plainTextEdit.appendPlainText("Chat general:\n")

    def send_nudge(self):
        if not (self.connection and self.connection.connected):
            QMessageBox.warning(self, "Error", "No estás conectado al servidor")
            return
        try:
            self.connection.server.send(bytes("<nudge>", 'utf-8'))
            self.plainTextEdit.appendPlainText("** Has enviado un zumbido! **\n")
        except Exception as e:
            self.plainTextEdit.appendPlainText(f"Error al enviar zumbido: {str(e)}\n")

    def shake_window(self):
        original_pos = self.pos()
        duration = 500
        interval = 50
        elapsed = 0

        def move():
            nonlocal elapsed
            offset_x = random.randint(-10, 10)
            offset_y = random.randint(-10, 10)
            self.move(original_pos + QPoint(offset_x, offset_y))
            elapsed += interval
            if elapsed >= duration:
                self.move(original_pos)
                timer.stop()

        timer = QTimer(self)
        timer.timeout.connect(move)
        timer.start(interval)

# ===== MultiSelect Dialog para grupos =====
class MultiSelectDialog(QDialog):
    def __init__(self, user_list):
        super().__init__()
        self.setWindowTitle("Seleccionar Usuarios")
        self.layout = QVBoxLayout(self)
        self.list_widget = QListWidget(self)
        self.list_widget.setSelectionMode(QListWidget.MultiSelection)
        for user in user_list:
            item = QListWidgetItem(user)
            self.list_widget.addItem(item)
        self.layout.addWidget(self.list_widget)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.layout.addWidget(self.buttons)

    def get_selected_users(self):
        return [item.text() for item in self.list_widget.selectedItems()]

# ===== MAIN =====
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
